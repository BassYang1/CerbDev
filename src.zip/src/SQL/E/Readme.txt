﻿[CerbDb.sql]  is the standard DB

[CerbDb_DefaultData.sql] Add default data, the default data are: a department, two employees and a controller 